from setuptools import setup

setup(
    name="SegundaEntregaDeCarli",
    version="1.0.0",
    description="Segunda Entrega",
    author="David De Carli",
    author_email="josedaviddc@gmail.com",
    packages=["SegundaEntregaDeCarli"]
)